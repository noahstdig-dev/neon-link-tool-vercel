from http.server import BaseHTTPRequestHandler
import json, ipaddress, socket
from urllib.parse import urlparse, urljoin
import requests

ALLOWED = {"bicolink.com", "sfl.gl"}
MAX_REDIRECTS = 8
TIMEOUT = 10

def validate_initial(url, service):
    if not isinstance(url, str) or len(url) > 4096:
        raise ValueError("URL tidak valid.")
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Gunakan URL HTTP/HTTPS yang valid.")
    host = p.hostname.lower().rstrip(".")
    if service not in ALLOWED or not (host == service or host.endswith("." + service)):
        raise ValueError("URL tidak cocok dengan layanan yang dipilih.")
    return url

def public_host(url):
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Redirect tujuan tidak valid.")
    host = p.hostname.lower().rstrip(".")
    try:
        addresses = [ipaddress.ip_address(host)]
    except ValueError:
        try:
            addresses = [ipaddress.ip_address(item[4][0]) for item in socket.getaddrinfo(host, None)]
        except (socket.gaierror, OSError):
            raise ValueError("Domain tujuan tidak dapat ditemukan.")
    if not addresses or any(not addr.is_global for addr in addresses):
        raise ValueError("Redirect menuju alamat IP non-publik; dihentikan demi keamanan.")
    return url

class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path.rstrip("/") != "/api/resolve":
            return self.reply(404, {"error":"Endpoint tidak ditemukan."})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 10000:
                return self.reply(400, {"error":"Permintaan tidak valid."})
            body = json.loads(self.rfile.read(length))
            service = body.get("service")
            current = validate_initial(body.get("url"), service)
            session = requests.Session()
            session.headers["User-Agent"] = "NeonLinkTool/1.0 (redirect checker)"
            history = []
            for _ in range(MAX_REDIRECTS + 1):
                public_host(current)
                # Disable automatic redirects; validate every target before requesting it.
                response = session.get(current, allow_redirects=False, timeout=TIMEOUT, stream=True)
                status = response.status_code
                location = response.headers.get("Location")
                content_type = response.headers.get("Content-Type", "").lower()
                history.append({"url": current, "status": status})
                response.close()
                if status in (301,302,303,307,308) and location:
                    current = public_host(urljoin(current, location))
                    continue
                if status in (401,403,429):
                    return self.reply(200, {"final_url":current,"reached_destination":False,
                        "note":f"Server mengembalikan HTTP {status}; mungkin perlu akses atau verifikasi manual.","history":history})
                if "text/html" in content_type:
                    return self.reply(200, {"final_url":current,"reached_destination":False,
                        "note":"Halaman web dijangkau, tetapi tujuan akhir mungkin memerlukan JavaScript atau verifikasi di browser.","history":history})
                return self.reply(200, {"final_url":current,"reached_destination":True,"note":None,"history":history})
            return self.reply(200, {"final_url":current,"reached_destination":False,
                "note":f"Pengalihan melebihi batas {MAX_REDIRECTS}.","history":history})
        except ValueError as exc:
            return self.reply(400, {"error":str(exc)})
        except requests.Timeout:
            return self.reply(504, {"error":"Waktu pemeriksaan habis."})
        except requests.RequestException:
            return self.reply(502, {"error":"Gagal terhubung ke server tujuan."})
        except Exception:
            return self.reply(500, {"error":"Terjadi kesalahan saat memeriksa URL."})

    def do_GET(self):
        return self.reply(405, {"error":"Gunakan POST."})

    def reply(self, status, data):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
