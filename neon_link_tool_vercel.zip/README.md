# Neon Link Tool — Vercel (mobile-friendly deployment)

## Upload from Android
1. Download and extract this ZIP using your phone's file manager.
2. Sign in to GitHub in your browser and create a new repository, e.g. `neon-link-tool`.
3. In the repository choose **Add file → Upload files** and upload `index.html`, `vercel.json`, `requirements.txt`, and the `api` folder containing `resolve.py`. Keep the folder structure exactly as shown.
4. Open Vercel in your browser and sign in with GitHub: https://vercel.com/
5. Choose **Add New → Project**, import `neon-link-tool`, then click **Deploy**.
6. When deployment completes, open the generated `*.vercel.app` link.

## Project structure
- `index.html` — dark neon UI with Bicolink/SFL.gl service selector
- `api/resolve.py` — Vercel Python serverless function for normal HTTP redirects
- `requirements.txt` — Python dependencies
- `vercel.json` — routing config

## Limits
This checks ordinary HTTP redirects only. It does not solve CAPTCHA, skip mandatory ads, execute page JavaScript, or bypass login/verification pages. Some short-link services may not expose the final URL via a normal HTTP redirect.
